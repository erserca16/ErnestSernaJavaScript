package clases;

import org.neodatis.odb.ODB;
import org.neodatis.odb.ODBFactory;
import org.neodatis.odb.Objects;

public class Actividad1 {

    public static void main(String[] args) {
        String dbName = "EQUIPOS.DB";
        ODB odb = ODBFactory.open(dbName);

        Objects<Paises> objetosPaises = odb.getObjects(Paises.class);

        int totalPaises = objetosPaises.size();
        System.out.println("Total de países en la base de datos: " + totalPaises);
        while (objetosPaises.hasNext()) {
            Paises pais = objetosPaises.next();
            System.out.println("- Pais: " + pais);
        }

        Objects<Jugadores> objetosJugadores = odb.getObjects(Jugadores.class);

        int totalJugadores = objetosJugadores.size();
        System.out.println("\nTotal de jugadores en la base de datos: " + totalJugadores);

        while (objetosJugadores.hasNext()) {
            Jugadores jugador = objetosJugadores.next();
            System.out.println("- Jugador: " + jugador.getNombre());
        }
        odb.close();
    }
}
