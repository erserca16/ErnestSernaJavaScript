package clases;

/**
 *
 * @author Ernest Serna
 */
import org.neodatis.odb.ODB;
import org.neodatis.odb.ODBFactory;
import org.neodatis.odb.Objects;
import org.neodatis.odb.core.query.IQuery;
import org.neodatis.odb.core.query.criteria.Where;
import org.neodatis.odb.impl.core.query.criteria.CriteriaQuery;

public class Actividad2 {

    public static void main(String[] args) {
        ODB odb = ODBFactory.open("EQUIPOS.DB");

        IQuery query = new CriteriaQuery(Jugadores.class, Where.equal("deporte", "tenis"));

        Objects<Jugadores> jueganTenis = odb.getObjects(query);

        System.out.println("Jugadores que practican tenis:");

        while (jueganTenis.hasNext()) {
            Jugadores jugadores = jueganTenis.next();
            System.out.println("Nombre: " + jugadores.getNombre() + " ," + "Pais: " + jugadores.getPais().getNombrePais());
        }

        odb.close();
    }
}


