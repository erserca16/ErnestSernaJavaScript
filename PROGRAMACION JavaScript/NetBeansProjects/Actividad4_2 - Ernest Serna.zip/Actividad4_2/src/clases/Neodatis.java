package clases;

/**
 *
 * @author Ernest Serna
 */
import clases.Jugadores;
import clases.Paises;
import org.neodatis.odb.ODB;
import org.neodatis.odb.ODBFactory;
import org.neodatis.odb.Objects;

public class Neodatis {

    public static void main(String[] args) {

        Paises pais1 = new Paises(1, "España");
        Paises pais2 = new Paises(2, "Francia");
        Paises pais3 = new Paises(3, "Portugal");
        Paises pais4 = new Paises(4, "Italia");

        Jugadores j1 = new Jugadores("Maria", "voleibol", pais1,14);
        Jugadores j2 = new Jugadores("Miguel", "tenis", pais2, 15);
        Jugadores j3 = new Jugadores("Mario", "baloncesto", pais3, 15);
        Jugadores j4 = new Jugadores("Alicia", "tenis", pais4, 14);
        
        ODB odb = ODBFactory.open("EQUIPOS.DB");
        //Almacenamos objetos

        odb.store(j1);
        odb.store(j2);
        odb.store(j3);
        odb.store(j4);
        
        odb.close();
    }
    
}
